#include "Attributes.h"

ACEXML_Attributes::~ACEXML_Attributes (void)
{
}
